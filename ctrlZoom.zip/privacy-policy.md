# The World’s Greatest Privacy Policy

We physically can’t.  We have nowhere to store it.  We don’t even have a server database to store it.  So even if Justin Bieber asked nicely to see your data, we wouldn’t have anything to show him.
_That’s why, what happens on your computer stays on your computer<sup>1</sup>._

<sup>1</sup>: Configurations are stored in your private chrome sync storage.